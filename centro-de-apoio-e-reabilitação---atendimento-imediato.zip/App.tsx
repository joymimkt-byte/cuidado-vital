
// Todo o código foi movido para o index.html a pedido do usuário.
export default function Empty() { return null; }
